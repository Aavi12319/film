# Film News Website

Deployed using Next.js + Tailwind on GitHub + Vercel.
